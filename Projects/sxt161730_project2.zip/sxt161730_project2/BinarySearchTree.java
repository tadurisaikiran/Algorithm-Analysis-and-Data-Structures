import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;

// BinarySearchTree class
//
// CONSTRUCTION: with no initializer
//
// ******************PUBLIC OPERATIONS*********************
// void insert( x )       --> Insert x
// void remove( x )       --> Remove x
// boolean contains( x )  --> Return true if x is present
// Comparable findMin( )  --> Return smallest item
// Comparable findMax( )  --> Return largest item
// boolean isEmpty( )     --> Return true if empty; else false
// void makeEmpty( )      --> Remove all items
// void printTree( )      --> Print tree in sorted order
// ******************ERRORS********************************
// Throws UnderflowException as appropriate

/**
 * Implements an unbalanced binary search tree. Note that all "matching" is
 * based on the compareTo method.
 * 
 * @author taduri
 *
 */

public class BinarySearchTree<AnyType extends Comparable<? super AnyType>> {
	/**
	 * Construct the tree.
	 */
	public BinarySearchTree() {
		root = null;
	}

	/**
	 * Insert into the tree; duplicates are ignored.
	 * 
	 * @param x
	 *            the item to insert.
	 */
	public void insert(AnyType x) {
		root = insert(x, root);
	}

	/**
	 * Remove from the tree. Nothing is done if x is not found.
	 * 
	 * @param x
	 *            the item to remove.
	 */
	public void remove(AnyType x) {
		root = remove(x, root);
	}

	/**
	 * Find the smallest item in the tree.
	 * 
	 * @return smallest item or null if empty.
	 */
	public AnyType findMin() {
		if (isEmpty())
			throw new UnderflowException();
		return findMin(root).element;
	}

	/**
	 * Find the largest item in the tree.
	 * 
	 * @return the largest item of null if empty.
	 */
	public AnyType findMax() {
		if (isEmpty())
			throw new UnderflowException();
		return findMax(root).element;
	}

	/**
	 * Find an item in the tree.
	 * 
	 * @param x
	 *            the item to search for.
	 * @return true if not found.
	 */
	public boolean contains(AnyType x) {
		return contains(x, root);
	}

	/**
	 * Make the tree logically empty.
	 */
	public void makeEmpty() {
		root = null;
	}

	/**
	 * Test if the tree is logically empty.
	 * 
	 * @return true if empty, false otherwise.
	 */
	public boolean isEmpty() {
		return root == null;
	}

	/**
	 * Print the tree contents in sorted order.
	 */
	public void printTree() {
		if (isEmpty())
			System.out.println("Empty tree");
		else
			printTree(root);
	}

	/**
	 * Recursively traverses the tree and returns the count of nodes
	 * 
	 * @return the count of nodes in a tree
	 */
	public int nodeCount() {
		return nodeCount(root);
	}

	/**
	 * Compares the structure of current tree to another tree and returns true if
	 * they match.
	 * 
	 * @param anotherTree
	 *            - reference of another tree
	 * @return
	 */
	public boolean compareStructure(BinarySearchTree<AnyType> anotherTree) {
		return compareStructure(this.root, anotherTree.root);

	}

	/**
	 * Compares the current tree to another tree and returns true if they are
	 * identical.
	 * 
	 * @param anotherTree
	 * @return
	 */
	public boolean equals(BinarySearchTree<AnyType> anotherTree) {
		return equals(this.root, anotherTree.root);
	}

	/**
	 * Creates and returns a new tree that is a copy of the original tree
	 * 
	 * @return
	 */
	public BinarySearchTree<AnyType> copy() {
		BinarySearchTree<AnyType> copyTree = new BinarySearchTree<>();
		copyTree.root = copy(this.root);
		return copyTree;
	}

	/**
	 * Creates and returns a new tree that is a mirror image of the original tree.
	 * 
	 * @return
	 */
	public BinarySearchTree<AnyType> mirror() {
		BinarySearchTree<AnyType> mirrorTree = new BinarySearchTree<>();
		mirrorTree.root = mirror(this.root);
		return mirrorTree;
	}

	/**
	 * Returns true if the tree is a mirror of the passed tree
	 * 
	 * @param passedTree
	 * @return
	 */
	public boolean isMirror(BinarySearchTree<AnyType> passedTree) {

		return isMirror(this.root, passedTree.root);
	}

	/**
	 * Performs a single right rotation on the node having the passed value.
	 * 
	 * @param x
	 *            - passed value
	 */
	public void rotateRight(AnyType x) {
		rotateRight(x, root);
	}

	/**
	 * Performs a single left rotation on the node having the passed value.
	 * 
	 * @param x
	 *            - passed value
	 */
	public void rotateLeft(AnyType x) {
		rotateLeft(x, root);
	}

	/**
	 * performs a level-by-level printing of the tree
	 */
	public void printLevels() {
		printLevels(root);
	}

	/**
	 * Method to check whether a tree is full binary tree or not
	 * 
	 * @return - Returns true if the tree is full
	 */
	public boolean isFull() {
		return isFull(root);
	}

	/**
	 * Internal method to insert into a subtree.
	 * 
	 * @param x
	 *            the item to insert.
	 * @param t
	 *            the node that roots the subtree.
	 * @return the new root of the subtree.
	 */
	private BinaryNode<AnyType> insert(AnyType x, BinaryNode<AnyType> t) {
		if (t == null)
			return new BinaryNode<>(x, null, null);

		int compareResult = x.compareTo(t.element);

		if (compareResult < 0)
			t.left = insert(x, t.left);
		else if (compareResult > 0)
			t.right = insert(x, t.right);
		else
			; // Duplicate; do nothing
		return t;
	}

	/**
	 * Internal method to remove from a subtree.
	 * 
	 * @param x
	 *            the item to remove.
	 * @param t
	 *            the node that roots the subtree.
	 * @return the new root of the subtree.
	 */

	private BinaryNode<AnyType> remove(AnyType x, BinaryNode<AnyType> t) {
		if (t == null)
			return t; // Item not found; do nothing

		int compareResult = x.compareTo(t.element);

		if (compareResult < 0)
			t.left = remove(x, t.left);
		else if (compareResult > 0)
			t.right = remove(x, t.right);
		else if (t.left != null && t.right != null) // Two children
		{
			t.element = findMin(t.right).element;
			t.right = remove(t.element, t.right);
		} else
			t = (t.left != null) ? t.left : t.right;
		return t;
	}

	/**
	 * Internal method to find the smallest item in a subtree.
	 * 
	 * @param t
	 *            the node that roots the subtree.
	 * @return node containing the smallest item.
	 */
	private BinaryNode<AnyType> findMin(BinaryNode<AnyType> t) {
		if (t == null)
			return null;
		else if (t.left == null)
			return t;
		return findMin(t.left);
	}

	/**
	 * Internal method to find the largest item in a subtree.
	 * 
	 * @param t
	 *            the node that roots the subtree.
	 * @return node containing the largest item.
	 */
	private BinaryNode<AnyType> findMax(BinaryNode<AnyType> t) {
		if (t != null)
			while (t.right != null)
				t = t.right;

		return t;
	}

	/**
	 * Internal method to find an item in a subtree.
	 * 
	 * @param x
	 *            is item to search for.
	 * @param t
	 *            the node that roots the subtree.
	 * @return node containing the matched item.
	 */
	private boolean contains(AnyType x, BinaryNode<AnyType> t) {
		if (t == null)
			return false;

		int compareResult = x.compareTo(t.element);

		if (compareResult < 0)
			return contains(x, t.left);
		else if (compareResult > 0)
			return contains(x, t.right);
		else
			return true; // Match
	}

	/**
	 * Internal method to print a subtree in sorted order.
	 * 
	 * @param t
	 *            the node that roots the subtree.
	 */
	private void printTree(BinaryNode<AnyType> t) {
		if (t != null) {
			printTree(t.left);
			System.out.println(t.element);
			printTree(t.right);
		}
	}

	/**
	 * Internal method to compute height of a subtree.
	 * 
	 * @param t
	 *            the node that roots the subtree.
	 */
	private int height(BinaryNode<AnyType> t) {
		if (t == null)
			return -1;
		else
			return 1 + Math.max(height(t.left), height(t.right));
	}

	/**
	 * Internal method to recursively traverse the tree and return the count of
	 * nodes
	 * 
	 * @param t
	 *            the node that roots the subtree
	 * @return the count of nodes in a tree
	 */
	private int nodeCount(BinaryNode<AnyType> t) {

		if (t == null)
			return 0;
		else
			return 1 + nodeCount(t.left) + nodeCount(t.right);

	}

	/**
	 * Internal method to check whether a tree is full binary tree or not
	 * 
	 * @param t
	 *            - the node that roots the subtree.
	 * @return - Returns true if the tree is full
	 */
	private boolean isFull(BinaryNode<AnyType> t) {
		boolean flag = true;
		if (t == null)
			return flag;

		Queue<BinaryNode<AnyType>> q = new LinkedList<>();

		q.add(t);
		while (!q.isEmpty()) {
			t = q.remove();
			if ((t.left != null && t.right != null) || (t.left == null && t.right == null)) {
				if (!(t.left == null && t.right == null)) {
					q.add(t.left);
					q.add(t.right);
				}

			} else {
				flag = false;
				break;
			}

		}

		return flag;
	}

	/**
	 * Internal method to Compare the structure of current tree to another tree and
	 * returns true if they match.
	 * 
	 * @param ct
	 *            - the node that roots the subtree of current tree.
	 * @param at
	 *            - the node that roots the subtree of another tree.
	 * @return
	 */
	private boolean compareStructure(BinaryNode<AnyType> ct, BinaryNode<AnyType> at) {
		if (ct == null && at == null)
			return true;
		else if (ct == null || at == null)
			return false;

		return ((compareStructure(ct.left, at.left)) && (compareStructure(ct.right, at.right)));

	}

	/**
	 * Internal method to Compare the current tree to another tree and returns true
	 * if they are identical.
	 * 
	 * @param ct
	 *            - the node that roots the subtree of current tree.
	 * @param at
	 *            - the node that roots the subtree of another tree.
	 * @return
	 */
	private boolean equals(BinaryNode<AnyType> ct, BinaryNode<AnyType> at) {

		if ((ct == null && at == null))
			return true;
		else if ((ct.element != at.element) || (ct == null || at == null))
			return false;
		if ((ct.element == at.element))
			return equals(ct.left, at.left) && equals(ct.right, at.right);
		return false;
	}

	/**
	 * Internal method to Create and return a new tree that is a copy of the
	 * original tree
	 * 
	 * @param t
	 *            - the node that roots the subtree of current tree
	 * @return
	 */
	private BinaryNode<AnyType> copy(BinaryNode<AnyType> t) {
		if (t == null)
			return null;
		if (t.left == null && t.right == null)
			return new BinaryNode<AnyType>(t.element, t.left, t.right);

		t.left = copy(t.left);
		t.right = copy(t.right);

		return t;
	}

	/**
	 * Internal Method to Create and return a new tree that is a mirror image of the
	 * original tree.
	 * 
	 * @param t
	 *            - the node that roots the subtree of original tree
	 * @return
	 */
	private BinaryNode<AnyType> mirror(BinaryNode<AnyType> t) {
		if (t == null)
			return null;
		if (t.left == null && t.right == null)
			return new BinaryNode<AnyType>(t.element, t.left, t.right);

		BinaryNode<AnyType> temp1 = mirror(t.left);
		BinaryNode<AnyType> temp2 = mirror(t.right);
		BinaryNode<AnyType> temp = new BinaryNode<AnyType>(t.element, temp2, temp1);

		return temp;
	}

	/**
	 * Internal method to Return true if the tree is a mirror of the passed tree.
	 * 
	 * @param t
	 *            - the node that roots the subtree of current tree
	 * @param pt
	 *            - the node that roots the subtree of passed tree
	 * @return
	 */
	private boolean isMirror(BinaryNode<AnyType> t, BinaryNode<AnyType> pt) {

		if (t == null && pt == null)
			return true;
		else if ((t == null || pt == null) || (t.element != pt.element))
			return false;

		if (t.element == pt.element)
			return (isMirror(t.left, pt.right) && isMirror(t.right, pt.left));

		return false;
	}

	/**
	 * Internal method to perform a single right rotation on the node having the
	 * passed value.
	 * 
	 * @param x
	 *            - passed value
	 * @param t
	 *            - the node that roots the subtree.
	 */
	private void rotateRight(AnyType x, BinaryNode<AnyType> t) {

		t = find(x, t);
		if (t == null) {
			throw new NoSuchElementException("No such element");
		}
		if (t.left == null)
			System.out.println("Cannot make a right rotation at node " + x);

		BinaryNode<AnyType> temp1 = t.left.right, temp2 = t.left;
		if (t.element == root.element) {
			root = t.left;
			t.left = temp1;
			temp2.right = t;

		} else {
			BinaryNode<AnyType> t1 = findParent(x, root);
			if (t1.left.element == x) {
				t1.left = temp2;
				t.left = temp1;
				temp2.right = t;
			} else {
				t1.right = temp2;
				t.left = temp1;
				temp2.right = t;
			}

		}

	}

	/**
	 * Internal method to find a node given its value
	 * 
	 * @param x
	 *            - Value of the node to be found
	 * @param t
	 *            - the node that roots the subtree.
	 * @return
	 */
	private BinaryNode<AnyType> find(AnyType x, BinaryNode<AnyType> t) {

		while (t != null && !(t.element.compareTo(x) == 0)) {
			if (x.compareTo(t.element) > 0)
				t = t.right;
			else if (x.compareTo(t.element) < 0)
				t = t.left;

		}
		return t;

	}

	/**
	 * Internal method to find the parent node of a given value
	 * 
	 * @param x
	 * @param t
	 * @return
	 */
	private BinaryNode<AnyType> findParent(AnyType x, BinaryNode<AnyType> t) {

		while (t != null && !(t.left.element.compareTo(x) == 0) && !(t.right.element.compareTo(x) == 0)) {
			if (x.compareTo(t.element) > 0)
				t = t.right;
			else if (x.compareTo(t.element) < 0)
				t = t.left;
		}
		return t;

	}

	/**
	 * Internal method to perform a single left rotation on the node having the
	 * passed value.
	 * 
	 * @param x
	 *            - passed value
	 * @param t
	 *            - root of the tree
	 */
	private void rotateLeft(AnyType x, BinaryNode<AnyType> t) {

		t = find(x, root);

		if (t == null)
			throw new NoSuchElementException("No such element");

		if (t.right == null) {
			System.out.println("Cannot make a left rotation at this node");
		}

		if (t.right != null) {
			BinaryNode<AnyType> temp = t, temp1 = t.right, temp2 = t.right.left;
			if (root.element == x) {
				root = temp1;
				temp1.left = temp;
				temp.right = temp2;
			} else {
				BinaryNode<AnyType> t1 = findParent(x, root);

				if (t1.left.element == x) {
					t1.left = temp1;
					t1.left.left = t;
					t.right = temp2;
				} else {
					t1.right = temp1;
					t1.left.left = t;
					t.right = temp2;
				}

			}

		}

	}

	/**
	 * Internal method to perform a level-by-level printing of the tree
	 * 
	 * @param t
	 *            the node that roots the subtree
	 */
	private void printLevels(BinaryNode<AnyType> t) {
		if (t == null)
			return;
		if (t.left == null && t.right == null) {
			System.out.println(t.element);

		}
		Queue<Queue<BinaryNode<AnyType>>> q = new LinkedList<>();
		Queue<BinaryNode<AnyType>> innerq = new LinkedList<>();

		innerq.add(t);
		q.add(innerq);
		while (!q.isEmpty()) {

			innerq = q.remove();
			Queue<BinaryNode<AnyType>> q1 = new LinkedList<>();
			if (innerq.isEmpty())
				break;
			while (!innerq.isEmpty()) {

				t = innerq.remove();

				System.out.print(t.element + "   ");
				if (t.left != null && t.right != null) {
					q1.add(t.left);
					q1.add(t.right);
				} else if (t.left == null && t.right != null) {
					q1.add(t.right);
				} else if (t.left != null && t.right == null) {
					q1.add(t.left);

				}

			}

			System.out.println();
			q.add(q1);

		}

	}

	// Basic node stored in unbalanced binary search trees
	private static class BinaryNode<AnyType> {
		// Constructors
		BinaryNode(AnyType theElement) {
			this(theElement, null, null);
		}

		BinaryNode(AnyType theElement, BinaryNode<AnyType> lt, BinaryNode<AnyType> rt) {
			element = theElement;
			left = lt;
			right = rt;
		}

		AnyType element; // The data in the node
		BinaryNode<AnyType> left; // Left child
		BinaryNode<AnyType> right; // Right child

	}

	/** The tree root. */
	private BinaryNode<AnyType> root;

	// Test program
	public static void main(String[] args) {
		BinarySearchTree<Integer> t = new BinarySearchTree<>();
		final int NUMS = 100;
		final int GAP = 37;
		for (int i = GAP; i != 0; i = (i + GAP) % NUMS)
			t.insert(i);
		System.out.println("Sample Tree for counting number of nodes \n");
		t.printLevels();
		System.out.println("        a) nodeCount ");
		System.out.println("\nOUTPUT : ");

		System.out.println(" The number of nodes in the given tree " + t.nodeCount());
		BinarySearchTree<Integer> t1 = new BinarySearchTree<>();

		
		
		System.out.println("\n        b) isFull ");

		System.out.println("Sample tree to check isFull or not ");
		 t1.insert(8);
		 t1.insert(4);
		 t1.insert(2);
		 t1.insert(3);
		 t1.insert(1);
		 t1.insert(6);
		 t1.insert(7);
		 t1.insert(5);
		 t1.insert(12);
		 t1.insert(10);
		 t1.insert(14);
		 t1.insert(11);
		 t1.insert(9);
		 t1.insert(13);
		 t1.insert(15);
		 t1.printLevels();
		 System.out.println("\nOUTPUT : ");

		 System.out.println("\nThe given tree is a full binary tree : "+t1.isFull());

		BinarySearchTree<Integer> t2 = new BinarySearchTree<>();
		System.out.println("\n          c) compareStructure ");
		System.out.println(" \nTree 1 : \n");
		
		 t2.insert(5);
		 t2.insert(3);
		 t2.insert(8);
		 t2.insert(1);
		 t2.insert(4);
		 t2.printLevels();
		BinarySearchTree<Integer> anotherTree = new BinarySearchTree<>();
		anotherTree.insert(10);
		anotherTree.insert(5);
		anotherTree.insert(15);
		anotherTree.insert(2);
		anotherTree.insert(7);
		System.out.println("\nTree 2 : \n");
		anotherTree.printLevels();
		System.out.println("\nOUTPUT : ");

		System.out.println("\nBoth trees have the same structure : " + t2.compareStructure(anotherTree));
		BinarySearchTree<Integer> otherTree = new BinarySearchTree<>();
		
		 otherTree.insert(10);
		 otherTree.insert(5);
		 otherTree.insert(15);
		 otherTree.insert(2);
		 otherTree.insert(7);
		
		 System.out.println("\n        d) equals ");
			System.out.println(" \nTree 1 : \n");
			otherTree.printLevels();
			System.out.println(" \nTree 2 : \n");
			anotherTree.printLevels();
			System.out.println("\nBoth trees are identical : " + otherTree.equals(anotherTree));
			 System.out.println("\n        e) copy ");
			 System.out.println("\nSample tree : ");
			 t2.printLevels();
			BinarySearchTree<Integer> copyTree = t2.copy();
			System.out.println("\nOUTPUT : ");

			System.out.println("The Copied tree is : ");
			copyTree.printLevels();
			 
System.out.println("\n        f) mirror ");
System.out.println("\nSample tree : ");
BinarySearchTree<Integer> t3=new BinarySearchTree<>();
t3.insert(100);
t3.insert(50);
t3.insert(150);
t3.insert(40);
t3.insert(45);

t3.printLevels();
System.out.println("\nOUTPUT : ");

System.out.println("\nThe mirror of the above tree is :  ");
BinarySearchTree<Integer> mirrorTree = t3.mirror();
mirrorTree.printLevels();
System.out.println("\n        g) isMirror ");
System.out.println("\nSample Tree : ");
t3.printLevels();
System.out.println("\n Passed Tree : ");
mirrorTree.printLevels();
System.out.println("\nOUTPUT : ");
System.out.println("\nThe passed tree is a mirror of the given tree :  "+t3.isMirror(mirrorTree));

System.out.println("\n        h) rotateRight ");
System.out.println("\nSample Tree : ");
t3.printLevels();
System.out.println("\nOUTPUT : ");
System.out.println("\nTree after RotateRight on 100 is performed: ");
t3.rotateRight(100);
t3.printLevels();

System.out.println("\n        i) rotateLeft ");
System.out.println("\nSample Tree : ");
t3.printLevels();
System.out.println("\nOUTPUT : ");
System.out.println("\nTree after RotateLeft on 50 is performed: ");
t3.rotateLeft(50);
t3.printLevels();
	
System.out.println("\n        j) printLevels ");
System.out.println("\nSample tree : " );
t1.printTree();
System.out.println("\nOUTPUT : ");
System.out.println("\nlevel-by-level printing of the tree :");
t1.printLevels();

	}
}
