/**
 * Maze class to generate and display a maze
 * @author taduri
 *
 */
public class Maze
{
	 	
	    private int rows;
	    private int columns;
	    private int length;
	    private Square[] square;

	    public Maze(int rows, int columns)
	    {
	        this.rows = rows;
	        this.columns = columns;
	        this.length = rows * columns;
	        this.square = new Square[this.length];

	        for(int i = 0; i < this.length; i++)
	        {
	            square[i] = new Square();
	        }
	        
	        DisjSets disjSets = new DisjSets(length);
	        
	        for(int count = 1; count <= length - 1;  )
	        {
	        	for(boolean flag = false; !flag; )
	        	{
	        		int a;
	        		int i = (int) (Math.random() * length);
	        		int j;
	        		if(i == 0)
	    			{
	    				a = (int)(Math.random() * 2);
	    				if(a == 0)
	    					j = i + 1;
	    				else
	    					j = i + columns;
	    			}
	        		else if(i == columns - 1)
	        		{
	    				a = (int)(Math.random() * 2);
	    				if(a == 0)
	    					j = i - 1;
	    				else
	    					j = i + columns;
	    			}
	        		else if(i == length - columns)
	        		{
	    				a = (int)(Math.random() * 2);
	    				if(a == 0)
	    					j = i - columns;
	    				else
	    					j = i + 1;
	    			}	
	        		else if(i == length - 1)
	        		{
	    				a = (int)(Math.random() * 2);
	    				if(a == 0)
	    					j = i - 1;
	    				else
	    					j = i - columns;
	    			}
	        		else if(i > 0 && i < columns - 1)
	        		{
	        			a = (int)(Math.random() * 3);
	    				if(a == 0)
	    					j = i - 1;
	    				else if(a == 1)
	    					j = i + 1; 	
	    				else
	    					j = i + columns;
	        		}
	        		else if(i % columns == 0)
	        		{
	        			a = (int)(Math.random() * 3);
	    				if(a == 0)
	    					j = i - columns;
	    				else if(a == 1)
	    					j = i + 1; 	
	    				else
	    					j = i + columns;
	        		}	
	        		else if(i > length - columns && i < length - 1)
	        		{
	        			a = (int)(Math.random() * 3);
	    				if(a == 0)
	    					j = i - columns;
	    				else if(a == 1)
	    					j = i - 1; 	
	    				else
	    					j = i + 1;
	        		}
	        		else if(i % columns == columns - 1)
	        		{
	        			a = (int)(Math.random() * 3);
	    				if(a == 0)
	    					j = i - columns;
	    				else if(a == 1)
	    					j = i - 1; 	
	    				else
	    					j = i + columns;
	        		}
	        		else
	        		{
	        			a = (int)(Math.random() * 4);
	    				if(a == 0)
	    					j = i - columns;
	    				else if(a == 1)
	    					j = i - 1; 	
	    				else if(a == 2)
	    					j = i + 1;
	    				else
	    					j = i + columns;
	        		}
	        		int set1 = disjSets.find(i);
	        		int set2 = disjSets.find(j);
	        		if(set1 != set2)
	        		{
	        			disjSets.union(set1, set2);
	        			if(j == i - columns)
	        				this.square[j].down = false;
	        			else if(j == i - 1)
	        				this.square[j].right = false;
	        			else if(j == i + 1)
	        				this.square[i].right = false;
	        			else if(j == i + columns)
	        				this.square[i].down = false;
	        			else
	        				;
	            		flag = true;
	            		count++;
	        		}       			       			
	        	}      	
	        }
	    }
    class Square
    {
        public boolean up;
        public boolean down;
        public boolean left;
        public boolean right;

        public Square()
        {
            down = true;
            right = true;
        }

        public void print()
        {
            if(down == true)
                System.out.print("_");
            else
                System.out.print(" ");
            if(right == true)
                System.out.print("|");
            else
                System.out.print(" ");
        }
    }

   

    public void print()
    {
        System.out.print("  ");

        for(int i = 1; i < this.columns; i++)
        {
            System.out.print(" _");
        }
        System.out.println();

        for(int i = 0; i < this.length - 1; i++)
        {
            if(i % this.columns == 0)
            {
            	if(i == 0)
            		System.out.print(" ");
            	else
            		System.out.print("|");
            }            
            
            this.square[i].print();
            
            if(i % this.columns == this.columns - 1)
            {
                System.out.println();
            }
        }
    }
    
}
