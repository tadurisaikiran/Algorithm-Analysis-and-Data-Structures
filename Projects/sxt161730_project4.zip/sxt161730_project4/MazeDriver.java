import java.util.Scanner;

public class MazeDriver
{
    public static void main(String [] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please specify the number of rows and columns in the maze, at least up to 20x20.");
        System.out.print("rows : ");
        int rows = scanner.nextInt();
        System.out.print("columns : ");

        int columns = scanner.nextInt();
        scanner.close();
        Maze maze = new Maze(rows, columns);
        maze.print();
        
    }
}
