import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;
import java.util.Scanner;

/**
 * 
 * @author taduri
 *
 * @param <AnyType>
 * 			any object
 * 
 * MyStack class uses an ArrayList to make a stack
 * 
 * MyStack class  demonstrates the nested symbol algorithm
 */
 public class MyStack<AnyType> {

	 List<AnyType> stack=new ArrayList<>();
	
	/**
	 * Adds an item to this collection, at the end.
	 * @param item
	 * 			Object to be pushed into the stack
	 */
	public void push(AnyType item) {
		stack.add(item);		
	}
	 
	/**
	 * Removes an item from the collection, from the end/top
	 * @return
	 * 		return object
	 */
	public AnyType pop() {
		if (stack.size()==0) {
			System.out.println("Stack is empty");
			throw new EmptyStackException();
		}
		else {
			AnyType top = stack.get(stack.size()-1);
			stack.remove(stack.size()-1);
			return top;
		}
		
		
	}
	
	/**
	 * 
	 * @return
	 * 	true if stack is empty
	 * 	false if stack is not empty
	 */
	public boolean isEmpty() {
		if (stack.size()==0)
			return true;
		else
			return false;
	}
}
 class TestMyStack{
		
	 public static void main(String[] args) throws Exception	{	
	 		MyStack<Character> myStack=new MyStack<>();
	 		System.out.println("Enter an Expression " );
	 		Scanner in=new Scanner(System.in);
	 		String str=in.nextLine();
	 		int flag=0;
	 		int i;
	 		for ( i=0;i<str.length();i++) {
	 			
	 			char c=str.charAt(i);
	 			switch(c) {
	 			case '[' : myStack.push(c);
	 						break;
	 			case '(' : myStack.push(c);
	 						break;
	 			case '{' : myStack.push(c);
	 						break;
	 						
	 			case ']' : if (!myStack.isEmpty() || i==0) {
	 				char x=myStack.pop();
	 				if (x!='[') {
	 					System.out.println("the symbol popped is not the matching opening symbol");
	 				}
	 			}
	 			flag=1;
	 			break;
	 			
	 			case ')' : if (!myStack.isEmpty() || i==0)  {
	 				char x=myStack.pop();
	 				if (x!='(') {
	 					System.out.println("the symbol popped is not the matching opening symbol");
	 				}
	 			}
	 			flag=1;

	 			break;
	 			case '}' : if (!myStack.isEmpty() || i==0) {
	 				char x=myStack.pop();
	 				if (x!='{') {
	 					System.out.println("the symbol popped is not the matching opening symbol");
	 				}
	 			}
	 			flag=1;

	 			break;
	 			}
	 			if (flag==1)
	 				break;
	 		}
	 		if (myStack.isEmpty() && i!=0)
	 			System.out.println("Given expression has balanced symbols");
	 		else
	 			System.out.println("Given expression does not have balanced symbols");
	 	}
	 	}