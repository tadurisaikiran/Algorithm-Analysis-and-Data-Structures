import java.util.Scanner;

/**
 * 
 * @author taduri
 *  LinkedList class implements a doubly-linked list.
 * @param <AnyType>
 */
public class MyLinkedList<AnyType> implements Iterable<AnyType> {
	/**
	 * Construct an empty LinkedList.
	 */
	public MyLinkedList() {
		doClear();
	}

	private void clear() {
		doClear();
	}

	/**
	 * Change the size of this collection to zero.
	 */
	public void doClear() {
		beginMarker = new Node<>(null, null, null);
		endMarker = new Node<>(null, beginMarker, null);
		beginMarker.next = endMarker;

		theSize = 0;
		modCount++;
	}

	/**
	 * Returns the number of items in this collection.
	 * 
	 * @return the number of items in this collection.
	 */
	public int size() {
		return theSize;
	}

	public boolean isEmpty() {
		return size() == 0;
	}

	/**
	 * Adds an item to this collection, at the end.
	 * 
	 * @param x
	 *            any object.
	 * @return true.
	 */
	public boolean add(AnyType x) {
		add(size(), x);
		return true;
	}

	/**
	 * Adds an item to this collection, at specified position. Items at or after
	 * that position are slid one position higher.
	 * 
	 * @param x
	 *            any object.
	 * @param idx
	 *            position to add at.
	 * @throws IndexOutOfBoundsException
	 *             if idx is not between 0 and size(), inclusive.
	 */
	public void add(int idx, AnyType x) {
		addBefore(getNode(idx, 0, size()), x);
	}

	/**
	 * Adds an item to this collection, at specified position p. Items at or after
	 * that position are slid one position higher.
	 * 
	 * @param p
	 *            Node to add before.
	 * @param x
	 *            any object.
	 * @throws IndexOutOfBoundsException
	 *             if idx is not between 0 and size(), inclusive.
	 */
	private void addBefore(Node<AnyType> p, AnyType x) {
		Node<AnyType> newNode = new Node<>(x, p.prev, p);
		newNode.prev.next = newNode;
		p.prev = newNode;
		theSize++;
		modCount++;
	}

	/**
	 * Returns the item at position idx.
	 * 
	 * @param idx
	 *            the index to search in.
	 * @throws IndexOutOfBoundsException
	 *             if index is out of range.
	 */
	public AnyType get(int idx) {
		return getNode(idx).data;
	}

	/**
	 * Changes the item at position idx.
	 * 
	 * @param idx
	 *            the index to change.
	 * @param newVal
	 *            the new value.
	 * @return the old value.
	 * @throws IndexOutOfBoundsException
	 *             if index is out of range.
	 */
	public AnyType set(int idx, AnyType newVal) {
		Node<AnyType> p = getNode(idx);
		AnyType oldVal = p.data;

		p.data = newVal;
		return oldVal;
	}

	/**
	 * Gets the Node at position idx, which must range from 0 to size( ) - 1.
	 * 
	 * @param idx
	 *            index to search at.
	 * @return internal node corresponding to idx.
	 * @throws IndexOutOfBoundsException
	 *             if idx is not between 0 and size( ) - 1, inclusive.
	 */
	private Node<AnyType> getNode(int idx) {
		return getNode(idx, 0, size() - 1);
	}

	/**
	 * Gets the Node at position idx, which must range from lower to upper.
	 * 
	 * @param idx
	 *            index to search at.
	 * @param lower
	 *            lowest valid index.
	 * @param upper
	 *            highest valid index.
	 * @return internal node corresponding to idx.
	 * @throws IndexOutOfBoundsException
	 *             if idx is not between lower and upper, inclusive.
	 */
	private Node<AnyType> getNode(int idx, int lower, int upper) {
		Node<AnyType> p;

		if (idx < lower || idx > upper)
			throw new IndexOutOfBoundsException("getNode index: " + idx + "; size: " + size());

		if (idx < size() / 2) {
			p = beginMarker.next;
			for (int i = 0; i < idx; i++)
				p = p.next;
		} else {
			p = endMarker;
			for (int i = size(); i > idx; i--)
				p = p.prev;
		}

		return p;
	}

	/**
	 * Removes an item from this collection.
	 * 
	 * @param idx
	 *            the index of the object.
	 * @return the item was removed from the collection.
	 */
	public AnyType remove(int idx) {
		return remove(getNode(idx));
	}

	/**
	 * Removes the object contained in Node p.
	 * 
	 * @param p
	 *            the Node containing the object.
	 * @return the item was removed from the collection.
	 */
	private AnyType remove(Node<AnyType> p) {
		p.next.prev = p.prev;
		p.prev.next = p.next;
		theSize--;
		modCount++;

		return p.data;
	}

	/**
	 * Returns a String representation of this collection.
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder("[ ");

		for (AnyType x : this)
			sb.append(x + " ");
		sb.append("]");

		return new String(sb);
	}

	/**
	 * Obtains an Iterator object used to traverse the collection.
	 * 
	 * @return an iterator positioned prior to the first element.
	 */
	public java.util.Iterator<AnyType> iterator() {
		return new LinkedListIterator();
	}

	/**
	 * This is the implementation of the LinkedListIterator. It maintains a notion
	 * of a current position and of course the implicit reference to the
	 * MyLinkedList.
	 */
	private class LinkedListIterator implements java.util.Iterator<AnyType> {
		private Node<AnyType> current = beginMarker.next;
		private int expectedModCount = modCount;
		private boolean okToRemove = false;

		public boolean hasNext() {
			return current != endMarker;
		}

		public AnyType next() {
			if (modCount != expectedModCount)
				throw new java.util.ConcurrentModificationException();
			if (!hasNext())
				throw new java.util.NoSuchElementException();

			AnyType nextItem = current.data;
			current = current.next;
			okToRemove = true;
			return nextItem;
		}

		public void remove() {
			if (modCount != expectedModCount)
				throw new java.util.ConcurrentModificationException();
			if (!okToRemove)
				throw new IllegalStateException();

			MyLinkedList.this.remove(current.prev);
			expectedModCount++;
			okToRemove = false;
		}
	}

	/**
	 * swapping two elements given their indexes 
	 * idx1 and idx2 are the index positions of the nodes to be swapped
	 * @param idx1
	 * 			index position of the element to be swapped
	 * @param idx2
	 * 			index position of the element to be swapped
	 * node1 points to the node at idx1 
	 * node2 points to the node at idx2 
	 * temp1 and temp2 are for storing temporary references
	 * 
	 */

	public void swap(int idx1, int idx2) {

		int size = size();
		if (idx1 > size - 1 || idx2 > size - 1 || idx1 < 0 || idx2 < 0)
			throw new IndexOutOfBoundsException("please enter valid index positions");

		Node<AnyType> node1 = getNode(idx1);
		Node<AnyType> node2 = getNode(idx2);
		Node<AnyType> temp1;
		Node<AnyType> temp2;

		if (node1 == node2)
			return;

		if (node1.next == node2) { // adjacent nodes
			node1.next = node2.next;
			node2.prev = node1.prev;
			node1.next.prev = node1;
			node2.prev.next = node2;
			node2.next = node1;
			node1.prev = node2;
		} else {
			temp1 = node1.next;
			temp2 = node2.prev;

			node1.next = node2.next;
			node2.prev = node1.prev;
			node1.next.prev = node1;
			node2.prev.next = node2;

			node2.next = temp1;
			node2.next.prev = node2;
			node1.prev = temp2;
			node1.prev.next = node1;

		}

	}
/**
 * Shifts the elements in the list 
 * @param number
 * 			shifts the list forward if number is positive or backward if negative
 */
	public void shift(int number) {

		if (number % size() == 0)
			return;
		if (number < 0) {
			number += size();
		}
		number %= size();
		Node<AnyType> node, temp;
		node = getNode(number);

		temp = endMarker;
		endMarker.prev.next = beginMarker.next;
		node.prev.next = endMarker;
		beginMarker.next.prev = temp.prev;
		endMarker.prev = node.prev;
		beginMarker.next = node;
		node.prev = beginMarker;

	}

	/**
	 * This is the doubly-linked list node.
	 */
	private static class Node<AnyType> {
		public Node(AnyType d, Node<AnyType> p, Node<AnyType> n) {
			data = d;
			prev = p;
			next = n;
		}

		public AnyType data;
		public Node<AnyType> prev;
		public Node<AnyType> next;
	}

	private int theSize;
	private int modCount = 0;
	private Node<AnyType> beginMarker;
	private Node<AnyType> endMarker;

	/**
	 * Inserts a new list at the specified index 
	 * @param newList
	 * 			list of elements to be inserted/copied
	 * @param index
	 * 			index position at which the newList has to be inserted
	 */
	public void insertList(MyLinkedList<AnyType> newList, int index) {

		if (index >= size()) {
			throw new IndexOutOfBoundsException("The provided index is greater than the list size");
		}
		if (newList.size() == 0)
			return;

		Node<AnyType> node = getNode(index);

		Node<AnyType> temp = node.prev;

		Node<AnyType> newNode = newList.beginMarker.next;

		temp.next = newNode;
		newNode.prev = temp;
		node.prev = newList.endMarker.prev;
		newList.endMarker.prev.next = node;
		theSize += newList.size();

	}
/**
 * Erase elements of a list given index and number of elements to be deleted from the index
 * @param index
 * 			index position from which the elements are to be deleted
 * @param number
 * 			number of elements to be deleted 
 * @throws Exception
 * 			IndexOutOfBoundsException
 *	           if index is not between 0 and size of the list, inclusive.
 * 			
 */
	public void erase(int index, int number) throws Exception {

		if (index < 0 || index >= size()) {
			throw new IndexOutOfBoundsException("The provided index is incorrect");
		}

		if (number >= size()) {
			throw new Exception("Given number exceeded the size of the list");
		}

		if (number > size() - index) {
			throw new Exception("Given number is incorrect");
		}

		Node<AnyType> node = getNode(index);
		Node<AnyType> temp = node;
		int count = 1;
		while (count < number) {
			temp = temp.next;
			count++;
		}

		node.prev.next = temp.next;
		temp.next.prev = node;
		theSize-=number;
	}

}

class TestLinkedList {
	public static void main(String[] args) throws Exception {
		Scanner in = new Scanner(System.in);
		MyLinkedList<Integer> lst = new MyLinkedList<>();
		for (int i = 1; i <= 10; i++)
			lst.add(i);
		System.out.println("/**"+"\n"+"  Initial list has 10 elements");
		System.out.println(lst);
		System.out.println("\n"+"**/");

		
		
while (true) {
		System.out.println("Enter" + "\n" + "1. Swap " + "\n" + "2. Shift" + "\n" + "3. erase" + "\n" + "4. insertList"+"\n"+"5. Exit");
		int choice = in.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter the two index positions to be swapped");
			int index1 = in.nextInt();
			int index2 = in.nextInt();
			lst.swap(index1, index2);
			System.out.println("List after swapping elements at indexes " + index1 + " and " + index2 + "is " + lst);
			break;

		case 2:
			System.out.println("Enter an integer (positive or negative)");
			int integer = in.nextInt();
			lst.shift(integer);
			System.out.println("List After shifting  " + integer + " positions " + lst);
			break;

		case 3:
			System.out.println("Enter an index position and number of elements to be removed");
			System.out.println("Enter Index position :");
			int index = in.nextInt();
			System.out.println("Enter Number of elements to be removed :");
			int number = in.nextInt();
			lst.erase(index, number);
			System.out.println("List After erasing" + number + "  elements starting from index positon " + index + "  " + lst);
			break;

		case 4:
			System.out.println("Enter size of a new List");
			int size = in.nextInt();
			MyLinkedList<Integer> newList = new MyLinkedList<>();
			for (int i = 0; i < size; i++)
				newList.add(in.nextInt());
			System.out.println("Enter an index position where the new list has to be inserted");
			int idx = in.nextInt();
			lst.insertList(newList, idx);
			System.out.println("List After inserting new elements at index postion "+idx+" " + lst);
			break;
			
		case 5 : System.out.println("Exiting");
			System.exit(0);
		break;
		}
}

	}
}