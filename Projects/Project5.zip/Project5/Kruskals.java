import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 * class to find the Minimum Spanning tree
 * 
 * @author taduri
 *
 */

public class Kruskals {

	/**
	 * Class to represent a graph
	 */
	public static class Graph {
		List<String> vertices; // vertices of graph
		List<Edge> adj; // adjacency list

		public Graph() {
			vertices = new ArrayList<>();
			adj = new LinkedList<>();
		}

		/**
		 * Nested class that represents an edge of a Graph
		 */
		public class Edge implements Comparable<Edge> {
			String from; // head vertex
			String to; // tail vertex
			int distance; // weight of edge

			/**
			 * Constructor for Edge
			 * 
			 * @param from
			 *            : String - Vertex from which edge starts
			 * @param to
			 *            : String - Vertex on which edge lands
			 * @param weight
			 *            : int - Weight of edge
			 */
			public Edge(String from, String to, int distance) {
				this.from = from;
				this.to = to;
				this.distance = distance;
			}

			/**
			 * Method to find the other end end of an edge, given a vertex reference
			 * 
			 * @param from
			 * @return - otherEnd of from
			 */
			public String otherEnd(String from) {
				return to;
			}

			@Override
			public int compareTo(Edge o) {
				if (this.distance < o.distance)
					return -1;
				else
					return (this.distance > o.distance) ? 1 : 0;
			}

		}

		/**
		 * Method to add an edge to the graph
		 * 
		 * @param from
		 *            : String - one end of edge
		 * @param to
		 *            : String - other end of edge
		 * @param weight
		 *            : int - the weight of the edge
		 */
		public void addEdge(String from, String to, int cost) {
			Edge e = new Edge(from, to, cost);
			adj.add(e);
		}

		/**
		 * read an undirected graph using the Scanner interface
		 * 
		 * @param in
		 */
		public void readAdjacencyList(Scanner in) {
			while (in.hasNext()) {
				String s = in.nextLine();
				String[] str = s.split(",");
				vertices.add(str[0]);
				for (int i = 1; i < str.length; i++) {

					addEdge(str[0], str[i], Integer.parseInt(str[++i]));
				}
			}
		}

	}

	/**
	 * Method to find the Minimum Spanning Tree
	 * 
	 * @param g
	 *            - given graph
	 */
	public void kruskal(Graph g) {
		int totalDistance = 0;

		PriorityQueue<Graph.Edge> pq = new PriorityQueue<>();
		int size = g.vertices.size();
		System.out.println("Number of Vertices : " + size);
		System.out.println("\nThe following are the edges of the minimum spanning tree as the names of the two cities and the distance between them\n ");
		
		for (Graph.Edge e : g.adj) {
			pq.add(e);
		}
		int edgesAccepted = 0;
		DisjSets ds = new DisjSets(size);
		Graph.Edge e;

		while (edgesAccepted < size - 1) {
			e = pq.remove(); // get minimum edge = (u,v)
			int uset = ds.find(g.vertices.indexOf(e.from)); // find set vertex u is in.
			int vset = ds.find(g.vertices.indexOf(e.to)); // find set vertex v is in.
			if (uset != vset) // if not same set (not yet connected)
			{
				edgesAccepted++;
				System.out.println("Edge :  " + e.from + " -> " + e.to + "   ,  " + "Distance : " + e.distance); // connect them																			
				totalDistance += e.distance;
				ds.union(uset, vset);
			}
		}
		System.out.println("\n\nTotal distance of MST is : " + totalDistance);
	}

	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("***Input file path is given as Command Line argument*** \n");
		Scanner in;
		File inputFile = new File(args[0]);
		in = new Scanner(inputFile);
		Kruskals k = new Kruskals();
		Graph g = new Graph();
		g.readAdjacencyList(in);
		k.kruskal(g);
		in.close();
	}

}
