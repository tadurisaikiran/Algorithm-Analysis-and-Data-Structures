import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Class to represent a graph
 * 
 * @author taduri
 *
 */
public class Graph {

	List<String> vertices; // vertices of graph
	List<Edge> adj = new LinkedList<>(); //adjacency list

	public Graph() {
		vertices = new ArrayList<>();
	}

	// public static class String {
	// String vertex;
	// int index;
	//
	//
	//
	// public String(String vertex, int index) {
	// this.vertex = vertex;
	// this.index = index;
	// }
	//
	// }
	/**
	 * Nested class that represents an edge of a Graph
	 */
	public class Edge implements Comparable<Edge> {
		String from; // head vertex
		String to; // tail vertex
		int weight; // weight of edge

		/**
		 * Constructor for Edge
		 * 
		 * @param from
		 *            : String - Vertex from which edge starts
		 * @param to
		 *            : String - Vertex on which edge lands
		 * @param weight
		 *            : int - Weight of edge
		 */
		public Edge(String from, String to, int weight) {
			this.from = from;
			this.to = to;
			this.weight = weight;
		}
		/**
		 * Method to find the other end end of an edge, given a vertex reference
		 * @param from
		 * @return
		 * 	- otherEnd of from 
		 */
		public String otherEnd(String from) {
			return to;
		}

		@Override
		public int compareTo(Edge o) {
			if (this.weight < o.weight)
				return -1;
			else
				return (this.weight > o.weight) ? 1 : 0;
		}

	}

	/**
	 * Method to add an edge to the graph
	 * 
	 * @param from
	 *            : String - one end of edge
	 * @param to
	 *            : String - other end of edge
	 * @param weight
	 *            : int - the weight of the edge
	 */
	public void addEdge(String from, String to, int cost) {
		Edge e = new Edge(from, to, cost);
		adj.add(e);
	}

	/**
	 * read an undirected graph using the Scanner interface
	 * @param in
	 */
	public void readAdjacencyList(Scanner in) {
		while (in.hasNext()) {
			String s = in.nextLine();
			String[] str = s.split(",");
			vertices.add(str[0]);
			for (int i = 1; i < str.length; i++) {

				addEdge(str[0], str[i], Integer.parseInt(str[++i]));
			}
		}
	}

}