												Project 3
									
readMe.txt
------------

Folder contains three files :

1. MyHashTable.java
2. WordPuzzle.java
3. readMe.txt

To run the program, the file dictionary.txt should be given at runtime as runtime argument. 

To compile : 
javac WordPuzzle.java

To run :
java WordPuzzle /Users/taduri/Downloads/dictionary.txt


