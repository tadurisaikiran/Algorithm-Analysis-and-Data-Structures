
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class WordPuzzle {

	public void algorithmOne(char grid[][], MyHashTable<String> H) throws FileNotFoundException {
		List<String> words = new ArrayList<>();

		long start = System.currentTimeMillis();

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				sb.setLength(0);
				for (int k = 0; k + j < grid[i].length; k++) {
					sb.append(grid[i][j + k]);
					if (sb.length() > 30)
						break;
					if (H.containsWord(new String(sb))) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; j - k < grid[i].length && j - k >= 0; k++) {
					sb.append(grid[i][j - k]);
					if (sb.length() > 30)
						break;
					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i + k < grid.length; k++) {
					sb.append(grid[i + k][j]);
					if (sb.length() > 30)
						break;
					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i - k < grid.length && i - k >= 0; k++) {
					sb.append(grid[i - k][j]);
					if (sb.length() > 30)
						break;
					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i - k >= 0 && k + j < grid[i].length; k++) {
					sb.append(grid[i - k][j + k]);
					if (sb.length() > 30)
						break;
					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i - k >= 0 && j - k >= 0; k++) {
					sb.append(grid[i - k][j - k]);
					if (sb.length() > 30)
						break;
					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i + k < grid.length && j - k >= 0; k++) {
					sb.append(grid[i + k][j - k]);
					if (sb.length() > 30)
						break;
					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i + k < grid.length && k + j < grid[i].length; k++) {
					sb.append(grid[i + k][j + k]);
					if (sb.length() > 30)
						break;
					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}
			}
		}
		long end = System.currentTimeMillis();
		System.out.println("\n------------------ Algorithm 1 ------------------\n");
		System.out.println("\nThe following are the words found using algorithmOne from the grid \n" + words);
		System.out.println("Count of words : " + words.size());
		System.out.println("Time taken by  algorithmOne to find words: " + (end - start) + " ms");

	}

	public void algorithmTwo(char grid[][], MyHashTable<String> H) throws FileNotFoundException {

		List<String> words = new ArrayList<>();

		long start = System.currentTimeMillis();

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				sb.setLength(0);
				for (int k = 0; k + j < grid[i].length; k++) {
					sb.append(grid[i][j + k]);
					if (sb.length() > 30)
						break;
					if (!(H.containsPrefix(new String(sb)))) {
						break;
					}

					if (H.containsWord(new String(sb))) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; j - k < grid[i].length && j - k >= 0; k++) {
					sb.append(grid[i][j - k]);
					if (sb.length() > 30)
						break;
					if (!(H.containsPrefix(new String(sb)))) {
						break;
					}

					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i + k < grid.length; k++) {
					sb.append(grid[i + k][j]);
					if (sb.length() > 30)
						break;
					if (!(H.containsPrefix(new String(sb)))) {
						break;
					}
					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i - k < grid.length && i - k >= 0; k++) {
					sb.append(grid[i - k][j]);
					if (sb.length() > 30)
						break;
					if (!(H.containsPrefix(new String(sb)))) {
						break;
					}

					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i - k >= 0 && k + j < grid[i].length; k++) {
					sb.append(grid[i - k][j + k]);
					if (sb.length() > 30)
						break;
					if (!(H.containsPrefix(new String(sb)))) {
						break;
					}

					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i - k >= 0 && j - k >= 0; k++) {
					sb.append(grid[i - k][j - k]);

					if (!(H.containsPrefix(new String(sb)))) {
						break;
					}

					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i + k < grid.length && j - k >= 0; k++) {
					sb.append(grid[i + k][j - k]);
					if (sb.length() > 30)
						break;
					if (!(H.containsPrefix(new String(sb)))) {
						break;
					}

					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}

				sb.setLength(0);
				for (int k = 0; i + k < grid.length && k + j < grid[i].length; k++) {
					sb.append(grid[i + k][j + k]);
					if (sb.length() > 30)
						break;
					if (!(H.containsPrefix(new String(sb)))) {
						break;
					}

					if (H.containsWord(new String(sb)) && sb.length() > 1) {
						words.add(sb.toString());
					}
				}
			}
		}
		long end = System.currentTimeMillis();
		System.out.println("\n------------------ Algorithm 2 ------------------\n");
		System.out.println("The following are the words found using algorithmTwo from the grid \n" + words);
		System.out.println("Count of words : " + words.size());
		System.out.println("Time taken by  algorithmTwo to find words: " + (end - start) + " ms");

	}

	public static void main(String[] args) throws Exception {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of rows and coloumns of the grid");
		System.out.print("rows : ");
		int row = in.nextInt();
		System.out.print("columns : ");
		int col = in.nextInt();

		Random r = new Random();
		char[][] grid = new char[row][col];

		System.out.println("\n---------------Grid---------------\n");
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {

				char c = (char) (r.nextInt(26) + 'a');
				grid[i][j] = c;
				System.out.print(c + " ");

			}
			System.out.println();
		}
		in.close();
		MyHashTable<String> H = new MyHashTable<>();

		File inputFile = new File(args[0]);
		in = new Scanner(inputFile);

		while (in.hasNext()) {
			String word = in.next();
			H.insertOne(word);
			int i = 1;
			while (i < word.length()) {
				H.insertTwo(word.substring(0, i));
				i++;
			}
		}
		WordPuzzle wp = new WordPuzzle();

		wp.algorithmOne(grid, H);
		wp.algorithmTwo(grid, H);
		in.close();
	}
}
