
public class MyHashTable<AnyType>
{
    
    public MyHashTable( )
    {
        this( DEFAULT_TABLE_SIZE );
    }

    public MyHashTable( int size )
    {
        allocateArray( size );
    }
    
    
    public boolean insertOne( AnyType x )
    {
        int currentPos = findPos( x );
        if( isActive( currentPos ) )
            return false;

        if( array[ currentPos ] == null )
            ++occupied;
        array[ currentPos ] = new HashEntry<>( x, true, true, true );
        theSize++;
        if( occupied > array.length / 2 )
            rehash( );
        return true;
    }
    
    public boolean insertTwo( AnyType x )
    {
        int currentPos = findPos( x );
        if( isActive( currentPos ) )
            return false;

        if( array[ currentPos ] == null )
            ++occupied;
        array[ currentPos ] = new HashEntry<>( x, true, true, false );
        theSize++;
        if( occupied > array.length / 2 )
            rehash( );
        return true;
    }
    
    private void rehash( )
    {
        HashEntry<AnyType> [ ] oldArray = array;

        allocateArray( 2 * oldArray.length );
        occupied = 0;
        theSize = 0;

        for( HashEntry<AnyType> entry : oldArray )
        {
            if( entry != null && entry.isActive && entry.isWord)
                insertOne( entry.element );
            else if( entry != null && entry.isActive && !(entry.isWord))
                insertTwo( entry.element );
        }
    }
    
    
    
    private int myhash( AnyType x )
    {
        int hashVal = x.hashCode( );
        hashVal %= array.length;
        if( hashVal < 0 )
            hashVal += array.length;

        return hashVal;
    }

    private int findPos( AnyType x )
    {
        int offset = 1;
        int currentPos = myhash( x );
        while( array[ currentPos ] != null && !array[ currentPos ].element.equals( x ) )
        {
            currentPos += offset;  
            if( currentPos >= array.length )
                currentPos -= array.length;
        }
        
        return currentPos;
    }

    
    
    
    public int size( )
    {
        return theSize;
    }
    
    public int capacity( )
    {
        return array.length;
    }

    public boolean contains( AnyType x )
    {
        int currentPos = findPos( x );
        return isActive( currentPos );
    }
    
    public boolean containsWord( AnyType x )
    {
        int currentPos = findPos( x );
        return isWord(currentPos);
    }
    
    public boolean containsPrefix( AnyType x )
    {
        int currentPos = findPos( x );
        return isPrefix(currentPos);
    }

    private boolean isActive( int currentPos )
    {
        return array[ currentPos ] != null && array[ currentPos ].isActive;
    }
    
    private boolean isPrefix( int currentPos )
    {
        return array[ currentPos ] != null && array[ currentPos ].isActive && array[ currentPos ].isPrefix;
    }
    
    private boolean isWord( int currentPos )
    {
        return array[ currentPos ] != null && array[ currentPos ].isActive && array[ currentPos ].isWord;
    }
    
    private static class HashEntry<AnyType>
    {
        public AnyType  element;   // the element
        public boolean isActive;   // true if not deleted
        public boolean isPrefix;   // true if word is  a prefix 
        public boolean isWord;     // true if string is a word
       
        public HashEntry( AnyType e )
        {
            this( e, true, false, false );
        }

        public HashEntry( AnyType e, boolean i, boolean p, boolean w)
        {
            element  = e;
            isActive = i;
            isPrefix = p;
            isWord = w;
        }
    }

    private static final int DEFAULT_TABLE_SIZE = 1000;

    private HashEntry<AnyType> [ ] array; // The array of elements
    private int occupied;                 // The number of occupied cells
    private int theSize;                  // Current size

    public void displayHashTable()
    {
        System.out.println("key"+" value");
        for(int i = 0; i < capacity(); i++)
        {
            
            System.out.print(" "+i+"   ");
            if(array[i] == null)
                System.out.println("Null");
            else
                System.out.println(array[i].element+"  "+array[i].isPrefix+"  "+array[i].isWord);
        }
        
    }
    
    
    /**
     * Internal method to allocate array.
     * @param arraySize the size of the array.
     */
    private void allocateArray( int arraySize )
    {
        array = new HashEntry[ nextPrime( arraySize ) ];
    }

    /**
     * Internal method to find a prime number at least as large as n.
     * @param n the starting number (must be positive).
     * @return a prime number larger than or equal to n.
     */
    private static int nextPrime( int n )
    {
        if( n % 2 == 0 )
            n++;

        for( ; !isPrime( n ); n += 2 )
            ;

        return n;
    }

    /**
     * Internal method to test if a number is prime.
     * Not an efficient algorithm.
     * @param n the number to test.
     * @return the result of the test.
     */
    private static boolean isPrime( int n )
    {
        if( n == 2 || n == 3 )
            return true;

        if( n == 1 || n % 2 == 0 )
            return false;

        for( int i = 3; i * i <= n; i += 2 )
            if( n % i == 0 )
                return false;

        return true;
    }

}
